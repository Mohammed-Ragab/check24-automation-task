package com.testcases;

import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;
import pages.Check24CreditCardComparisonPage;
import pages.PersonalInfoPage;

import java.time.Duration;

public class CreditCardTest {


    WebDriver driver;
    @BeforeClass
    public void setup()
    {
        WebDriverManager.chromedriver().setup();
         driver = new ChromeDriver();
    }


    Check24CreditCardComparisonPage check24CreditCardComparisonPage = new Check24CreditCardComparisonPage();
    PersonalInfoPage personalInfoPage = new PersonalInfoPage();

    @Test
    public void testCreditCardApplication() {
        driver.get("https://finanzen.check24.de/accounts/d/kreditkarte/result.html");

        // accept the cookies button
        driver.findElement(check24CreditCardComparisonPage.cookieButton).click();

        // close the popup window
        driver.findElement(check24CreditCardComparisonPage.closePopupWindowButton).click();

        // Check for the cookie
          String cookieValue = driver.manage().getCookieNamed(check24CreditCardComparisonPage.cookieName).getValue();
          Assert.assertEquals(cookieValue, "kreditkarte");
          System.out.println("cookie value is " + cookieValue);


          // Click on the “zum Antrag” button on the first of the listed products which have the number "1" on itspanel (i.e. 1. Barclaycard Visa)
        driver.findElement(check24CreditCardComparisonPage.firstZumAntragButton).click();

        // fill the email text box

       // driver.findElement(personalInfoPage.emailTextBoxByCSS).click();
        //WebElement elem = new WebDriverWait(driver, Duration.ofSeconds(10)).until(ExpectedConditions.elementToBeClickable(By.cssSelector("#cl_login.c24-uli-input")));

        // Create JavascriptExecutor instance
          /// JavascriptExecutor js = (JavascriptExecutor) driver;
        // Get element by data-tid attribute using JavaScript
       /// WebElement element = (WebElement) js.executeScript("return document.querySelector('[data-tid=\"input-login\"]');");

      /*
    note: I could not locate the HTML element "text box of the email" by ID or xpath and I tried many  times  in the browser inspector page and I did not get it.

    the following are the xpath I tried:

    (//*[@id='cl_login'])[3]

   //*[@type='email']

for more information, refer to "PersonalInfoPage"
*/

    }


} // end of the class
