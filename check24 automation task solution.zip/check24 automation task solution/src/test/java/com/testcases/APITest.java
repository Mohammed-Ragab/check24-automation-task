package com.testcases;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.testng.annotations.*;

import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

public class APITest {

    @Test
    public void testEndpoints() {
        String[] ids = {"200007", "abcd", "5456"};

        for (String id : ids) {

            System.out.println("======================================================== ");
            System.out.println("response of ID " + id );

            Response response = RestAssured.get("https://finanzen.check24.de/accounts/r/frs/productInfo/kreditkarte/" + id);

            // Print the response for debugging purposes
            System.out.println("response is : " + response.asString());

            // Check the HTTP status code
            System.out.println("Check the HTTP status code ");
            System.out.println();
            assertThat(response.statusCode(), equalTo(200));

            System.out.println("============================================================================== ");

        }
    }




}
