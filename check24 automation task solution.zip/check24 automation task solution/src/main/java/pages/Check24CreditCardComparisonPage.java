package pages;


import org.openqa.selenium.By;

public class Check24CreditCardComparisonPage {


    String homepage_URL = "https://finanzen.check24.de/accounts/d/kreditkarte/result.html";


    public By cookieButton = By.xpath("(//*[@class='c24-cookie-consent-button'])[1]");
    public By closePopupWindowButton = By.xpath("//*[@class='credit-score__close']");

    public By firstZumAntragButton = By.xpath("(//a[contains(text(), 'zum Antrag')])[1]");


   public String cookieName = "ppset";
  public  String cookieValue = "kreditkarte";




}
