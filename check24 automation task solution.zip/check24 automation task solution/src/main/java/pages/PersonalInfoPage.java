package pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;

public class PersonalInfoPage {


    public By emailTextBox = By.id("cl_login");

    public By emailTextBoxByCSS = By.cssSelector("#cl_login.c24-uli-input");

    /*
    note: I could not locate the HTML element "text box of the email" by ID or xpath and I tried many  times  in the browser inspector page and I did not get it.

    the following are the xpath I tried:

    (//*[@id='cl_login'])[3]

   //*[@type='email']


    after searching on internet  it seems like it is Pseudo-elements which don't exist in the DOM tree (hence the name)

    reference:

    https://stackoverflow.com/questions/51992258/xpath-to-find-pseudo-element-after-in-side-a-div-element-with-out-any-content

    https://stackoverflow.com/questions/63845698/how-to-write-the-xpath-for-an-element-where-before-tag-is-involved

    */



}
